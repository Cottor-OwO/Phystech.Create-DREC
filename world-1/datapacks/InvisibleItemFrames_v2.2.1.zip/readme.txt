## Invisible Item Frames V2.2.1 ##
Added to the game but never made survival friendly, this pack aims to fix that!

## Usage ##
To make you item frame invisible press shift and right click on an item frame that has an item inside it with a pair of shears, this will make the item frame
disappear and damage the shears slightly, a new pair of undamaged shears will turn 20 item frames invisible.

If you have unbreaking enchantment on your shears this amount will increase...
Unbreaking 1 = 40 Item Frames
Unbreaking 2 = 60 Item Frames
Unbreaking 3 = 80 Item Frames

If no item is present inside of the item frame then they will reappear and have a "soul" particle to denote that it's an invisible item frame
Once an item is placed back into the frame it will disappear again leaving just the item.

To make the item frame no longer a invisible item frame simply break the item frame and place it back down (wow thats a lot of "Item Frame")

An Invisible Item Frame will not allow an item to be rotated to prevent accidental clicking due to lack of visible hitbox, to still allow
rotation when needed simply hold shift while right clicking on the item frame and the item will rotate again.

## Advancements ##
There is 1 visible advancements and several hidden advancements in this data pack,
The hidden Advancements for this pack are called "Just Hang It Up", "FrameCeption" and "You're So Predictable",
these will be unlocked when have done the action required to get them at which point you will receive a trophy!

## Bug Fix ##
If you have any issues with the pack not triggering an event you can run the following command which may fix it:
/function 8bm:reset

If you want to uninstall the pack, including all the scoreboards use the following commands
/function 8bm:uninstall.invisible_itemframes

## Declared Tags, FakePlayers, Scoreboards ##
If you are experiencing any compatibility issues my pack please make sure that the other pack isn't using any of the following:

- Main Directory
# 8bm

- Tags
# 8bm.debug
# 8bm.loops
# 8bm.invisframe.processed
# 8bm.invisframe.target
# 8BM_SIIF
# 8BM_IIFItem

- FakePlayers
# 8bm.advoff

- Scoreboard Objectives
# 8bm.iif.damage
# 8bm.iif.distance
# 8bm.iif.itemRot
# 8bm.feedback
# 8bm.uninstall
# 8bm.advswitch

## Socials ##

For more packs and for updates on packs that I have created you can find me at these places
- http://YouTube.com/The8BitMonkey
- http://www.The8BitMonkey.com/discord
- http://www.Twitter.com/The8BitMonkey
- http://www.planetminecraft.com/member/the8bitmonkey/

## Big Thanks ##
Thank you to the following community members for there tutorials and packs which helped me understand how datapacks work and how to create my own!
- Vdvman1: https://www.skylinerw.com/vdvman1/raycast/
- CloudWolf: https://www.youtube.com/channel/UCZnBqVITQ0dloqUU0fGxY3g
- Lagitimoose: https://www.youtube.com/channel/UCFkT7atm3HrSm5nYaXah5Ww
- GameMode4: https://gm4.co/
- Boomber: https://www.planetminecraft.com/member/boomber360/
- TimberForge: https://www.youtube.com/channel/UC606Jh3yjNj40dcVuMwtUCw
- Blakens: https://www.youtube.com/channel/UCP2FPkHsjojo2OJmXqSUk9Q
- Swashbuckle Games: https://www.youtube.com/channel/UCTvbLAf66VfMPlh8dIKnSEQ
- LittleWorldOfLilcat: https://www.youtube.com/channel/UClpZU5eeU9r0zfgu-34VNYg (for being such a supportive partner and testing all my packs)

## Change Log ##
Version 2.2.1
Rewrote advancement code to stop a recursive issue

Version 2.2.0
Rewrote the advancement scripting so that it can be enabled and disabled by an OP

Version 2.1.3
Rewrote the install message script to only appear when the pack is updated or when you reset the packs

Version 2.1.2
Added new blocks for 1.19 to raycast
(This version is no longer compatible with older version fo the game)

Version 2.1.1
Fixed bug related to block tags in 1.19
Updated to 1.19 pack format

Version 2.1.0
Added new and better raycast code by Vdvman1: https://www.skylinerw.com/vdvman1/raycast/
Items will no longer rotate in the item frame when made invisible to prevent accidental hits
Added ability to still rotate item by holding shift

Version 2.0.4
Included "reset script" to advancement trigger as it was left out of original code

Version 2.0.3
Changed Raycast distance to work with Creative Modes longer player reach

Version 2.0.2
Removed unused code
Fixed particle bug with 1.18

Version 2.0.1
Fixed bug with raycast
Removed damage for creative players

Version 2.0.0
Updated to 1.18.X
Updated shear machanic to damage shears in the players hands instead of the item frame
Fixed issue with unbreaking enchantment

Version 1.4.0
Updated to 1.17.X
Added functionality to "Glow Item Frames"

Version 1.3.4
Added Unbreaking Enchantment allowance
Added Creative Mode "warning"
Added rewritten uninstall script
Changed command structure
Changed ## Comments
Added efficiency to the way functions are activated
Changed advancement trigger nbt
Added "shear" sound when shears as used
Run invisible & particle commands off item_frames within 25 blocks of players location

Version 1.3.3
Added predicate for cross-pack integration check
Added load function
Changed minecraft:load target

Version 1.3.2
Fixed several bugs related to installation text
Fixed Raycast not working with cave air, small hitbox blocks and water
Change raycast activation distance to prevent it not working when stood within the same block as item frame
Added head name to trophies so that if they're placed and broken they retain some of the name

Version 1.3.1
Fixed raycast so that it will only run for around 10 blocks in front of player
Added particles to the "You're So Predictable" Advancement
Fixed "You're So Predictable" Advancement from activating at the wrong location

Version 1.3.0
Added Raycasting to effect only the item frame your looking at
Added predicates to stop raycast rotating item frame
Added soul particles to affected item frames
Added damage to shears that are being used to make invisible item frames
Added change log
